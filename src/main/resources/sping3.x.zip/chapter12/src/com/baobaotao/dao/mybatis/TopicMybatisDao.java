package com.baobaotao.dao.mybatis;

import com.baobaotao.domain.Topic;

public interface TopicMybatisDao {
	void addTopic(Topic topic);
}
