package com.baobaotao.service;

public class OtherJob implements Runnable {
	public void run() {
       System.out.println("do job in OtherJob.run()");
	}
}
