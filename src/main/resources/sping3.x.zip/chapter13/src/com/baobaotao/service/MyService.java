package com.baobaotao.service;

public class MyService {
   public void doJob(){
	   System.out.println("in MyService.dojob().");
   }
}
