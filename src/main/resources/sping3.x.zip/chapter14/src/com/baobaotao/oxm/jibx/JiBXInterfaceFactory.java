package com.baobaotao.oxm.jibx;
import java.util.ArrayList;
import java.util.List;
public class JiBXInterfaceFactory {
	/**
	 * ��ȡListʵ����ʵ��
	 * @return
	 */
	public static List getArrayListInstance(){
		return new ArrayList();
	}
}
