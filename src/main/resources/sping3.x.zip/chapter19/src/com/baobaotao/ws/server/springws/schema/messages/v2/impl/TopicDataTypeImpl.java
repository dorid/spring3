/*
 * XML Type:  topicDataType
 * Namespace: http://www.baobaotao.com/ws/server/springws/schema/messages/v2
 * Java type: com.baobaotao.ws.server.springws.schema.messages.v2.TopicDataType
 *
 * Automatically generated - do not modify.
 */
package com.baobaotao.ws.server.springws.schema.messages.v2.impl;
/**
 * An XML topicDataType(@http://www.baobaotao.com/ws/server/springws/schema/messages/v2).
 *
 * This is an atomic type that is a restriction of com.baobaotao.ws.server.springws.schema.messages.v2.TopicDataType.
 */
public class TopicDataTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements com.baobaotao.ws.server.springws.schema.messages.v2.TopicDataType
{
    private static final long serialVersionUID = 1L;
    
    public TopicDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TopicDataTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
