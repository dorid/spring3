package com.baobaotao.dao;

import org.unitils.UnitilsJUnit4;
import org.unitils.spring.annotation.SpringApplicationContext;

@SpringApplicationContext( {"classpath:/baobaotao-dao.xml" })
public class BaseDaoTest extends UnitilsJUnit4{
	
}
