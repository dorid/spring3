package com.baobaotao.exception;

public class NotLoginException extends RuntimeException{
	
}
