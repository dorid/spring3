package com.baobaotao.service;

import com.baobaotao.domain.Forum;

public interface BbtForum {
	void addForum(Forum forum);
}
