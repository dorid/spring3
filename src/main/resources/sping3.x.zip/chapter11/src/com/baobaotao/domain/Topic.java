package com.baobaotao.domain;

import java.io.Serializable;
import java.util.Date;

public class Topic implements Serializable {
	
}
