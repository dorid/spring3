package sample.junit;

public class Junit4LifecycleTest {
   
}
