package com.baobaotao.exception;

public class BusException extends RuntimeException {

}
