package com.baobaotao.web;

public class NotLoginException extends RuntimeException{
}
